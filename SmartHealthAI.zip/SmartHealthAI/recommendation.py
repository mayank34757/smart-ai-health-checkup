def get_recommendation(risk, diet, score):
    
    if risk == 0 and score >= 80:

        if diet == "Vegetarian":
            diet_plan = [
                "Oats + Fruits",
                "Paneer Salad",
                "Dal + Brown Rice",
                "Vegetable Soup",
                "Dry Fruits"
            ]
        else:
            diet_plan = [
                "Boiled Eggs",
                "Grilled Chicken",
                "Fish Curry",
                "Brown Rice",
                "Fruit Bowl"
            ]

        msg = "🎉 Excellent health! Keep it up."
        exercise = ["Jogging", "Yoga", "Light Gym"]
        tips = ["Stay hydrated", "Avoid junk food", "Regular sleep"]

    elif risk == 1:

        if diet == "Vegetarian":
            diet_plan = [
                "Vegetable Upma",
                "Curd + Roti",
                "Sprouts",
                "Salad"
            ]
        else:
            diet_plan = [
                "Egg Omelette",
                "Chicken Soup",
                "Grilled Fish",
                "Chapati"
            ]

        msg = "⚠️ Moderate risk. Improve lifestyle."
        exercise = ["Brisk Walk", "Cycling", "Stretching"]
        tips = ["Sleep 7+ hrs", "Reduce screen time"]

    else:

        if diet == "Vegetarian":
            diet_plan = [
                "Boiled Vegetables",
                "Moong Dal",
                "Oats Porridge",
                "Green Tea"
            ]
        else:
            diet_plan = [
                "Boiled Eggs",
                "Steamed Fish",
                "Chicken Broth",
                "Green Tea"
            ]

        msg = "❌ High risk. Take care immediately."
        exercise = ["Slow Walk", "Meditation", "Breathing"]
        tips = ["Consult doctor", "No junk food", "Stress control"]

    return {
        "diet": diet_plan,
        "exercise": exercise,
        "tips": tips,
        "message": msg
    }
