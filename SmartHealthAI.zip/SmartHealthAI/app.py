import streamlit as st
import joblib
import numpy as np
from recommendation import get_recommendation


# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="Smart Health AI", layout="centered")


# ---------------- CUSTOM CSS ----------------
st.markdown("""
<style>

/* Background */
.main {
    background: linear-gradient(135deg, #667eea, #764ba2);
    padding: 20px;
}

/* App container */
.block-container {
    background: rgba(255,255,255,0.95);
    border-radius: 20px;
    padding: 40px;
    max-width: 900px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.2);
}

/* Title */
h1 {
    color: #4f46e5;
    text-align: center;
    font-weight: 800;
    letter-spacing: 1px;
}

/* Subtitle */
p {
    color: #555;
}

/* Input cards */
.stNumberInput, .stSelectbox {
    background: #f8f9ff;
    border-radius: 12px;
    padding: 5px;
}

/* Input box */
.stNumberInput input {
    border-radius: 10px;
    border: 2px solid #6366f1;
}

/* Buttons */
.stButton button {
    background: linear-gradient(90deg, #ff512f, #dd2476);
    color: white;
    border-radius: 30px;
    height: 50px;
    width: 100%;
    font-size: 20px;
    font-weight: 600;
    border: none;
    box-shadow: 0 8px 20px rgba(221,36,118,0.4);
    transition: 0.3s;
}

.stButton button:hover {
    transform: scale(1.08);
    box-shadow: 0 12px 30px rgba(221,36,118,0.7);
}

/* Cards */
.card {
    background: linear-gradient(135deg, #ffffff, #f3f4ff);
    padding: 25px;
    border-radius: 18px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    margin: 25px 0 40px 0;

    border-left: 6px solid #6366f1;
}

/* Progress bar */
.progress-bar {
    background: #e0e7ff;
    border-radius: 30px;
    overflow: hidden;
    height: 25px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #06beb6, #48b1bf);
    text-align: center;
    color: white;
    font-weight: 600;
    font-size: 14px;
    line-height: 25px;
}

/* Section titles */
.card h3 {
    color: #4338ca;
    font-weight: 700;
}

/* Checkmarks */
.stMarkdown li {
    color: #111827;
    font-weight: 500;
}

/* Back button */
.stButton button[key="back_btn"] {
    background: linear-gradient(90deg, #11998e, #38ef7d);
}

/* Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}
::-webkit-scrollbar-thumb {
    background: #6366f1;
    border-radius: 10px;
}

</style>
""", unsafe_allow_html=True)



# ---------------- LOAD MODEL ----------------
model = joblib.load("health_model.pkl")


# ---------------- PAGE STATE ----------------
if "page" not in st.session_state:
    st.session_state.page = "form"


# ================= FORM PAGE =================
if st.session_state.page == "form":

    st.markdown("""
    <h1>💪 Smart AI Health Coach</h1>
    <p style="text-align:center;">Your Personal AI Fitness Assistant</p>
    """, unsafe_allow_html=True)

    st.write("### Enter your daily routine:")

    walk = st.number_input("Walking (hrs/day)", 0.0, 10.0)
    exercise = st.number_input("Exercise (hrs/day)", 0.0, 8.0)
    sit = st.number_input("Sitting (hrs/day)", 0.0, 15.0)
    sleep = st.number_input("Sleep (hrs/day)", 0.0, 12.0)
    screen = st.number_input("Screen Time (hrs/day)", 0.0, 20.0)
    water = st.number_input("Water (Litres/day)", 0.0, 10.0)

    diet = st.selectbox("Diet Preference", ["Vegetarian", "Non-Vegetarian"])

    if st.button("Analyze My Health", key="analyze_btn"):

        st.session_state.walk = walk
        st.session_state.exercise = exercise
        st.session_state.sit = sit
        st.session_state.sleep = sleep
        st.session_state.screen = screen
        st.session_state.water = water
        st.session_state.diet = diet

        st.session_state.page = "result"
        st.rerun()


# ================= RESULT PAGE =================
elif st.session_state.page == "result":

    walk = st.session_state.walk
    exercise = st.session_state.exercise
    sit = st.session_state.sit
    sleep = st.session_state.sleep
    screen = st.session_state.screen
    water = st.session_state.water
    diet = st.session_state.diet

    data = np.array([[walk, exercise, sit, sleep, screen, water]])

    risk = model.predict(data)[0]

    if risk == 0:
        score = 85
        status = "LOW RISK ✅"
        color = "green"
    elif risk == 1:
        score = 65
        status = "MEDIUM RISK ⚠️"
        color = "orange"
    else:
        score = 40
        status = "HIGH RISK ❌"
        color = "red"

    rec = get_recommendation(risk, diet, score)


    # Status
    st.markdown(f"""
    <div class="card">
        <h2 style="text-align:center;color:{color};">{status}</h2>
        <h3 style="text-align:center;">Fitness Score: {score}/100</h3>
    </div>
    """, unsafe_allow_html=True)


    # Progress
    st.markdown(f"""
    <div class="card">
        <h3>📊 Fitness Level</h3>
        <div class="progress-bar">
            <div class="progress-fill" style="width:{score}%;">
                {score}%
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)


    # Diet
    st.markdown("<div class='card'><h3>🥗 Diet Plan</h3>", unsafe_allow_html=True)
    for d in rec["diet"]:
        st.write("✔", d)
    st.markdown("</div>", unsafe_allow_html=True)


    # Exercise
    st.markdown("<div class='card'><h3>🏃 Exercise Plan</h3>", unsafe_allow_html=True)
    for e in rec["exercise"]:
        st.write("✔", e)
    st.markdown("</div>", unsafe_allow_html=True)


    # Tips
    st.markdown("<div class='card'><h3>💡 Lifestyle Tips</h3>", unsafe_allow_html=True)
    for t in rec["tips"]:
        st.write("✔", t)
    st.markdown("</div>", unsafe_allow_html=True)


    # AI Message
    st.markdown(f"""
    <div class="card">
        <h3>🤖 AI Advice</h3>
        <p>{rec["message"]}</p>
    </div>
    """, unsafe_allow_html=True)


    # Back Button
    if st.button("🔁 Check Again", key="back_btn"):
        st.session_state.page = "form"
        st.rerun()
